<?php
$URL="https://www.facebook.com/sea.kBz";
header ("Location: $URL");
?>