<?php
$db_host = 'share17.vhost.vn'; // MySQL DB Host
$db_user = 'automyth_kBz'; // MySQL DB User
$db_pass = '123kBz'; // MySQL DB Pass
$db_name = 'automyth_kBz'; // MySQL DB Name
$time_online = 180; // Đặt 3 Phút Online
$time_limit = 300; // Khoá 5 Phút Auto
?>