<?php
$db_host = 'localhost'; // MySQL DB Host
$db_user = ''; // MySQL DB User
$db_pass = ''; // MySQL DB Pass
$db_name = ''; // MySQL DB Name
$time_online = 180; // Đặt 3 Phút Online
$time_limit = 300; // Khoá 5 Phút Auto
?>