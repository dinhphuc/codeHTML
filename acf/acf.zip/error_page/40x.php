<?php
//----------LOAD LIBRARY----------//
require_once '../core/define.php';
require_once '../core/autoload.php';
//--------------------------------//
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="description" content="HOTLIKE.NET - Hệ Thống Auto Like, Bot Like, Boom Like, Sim Simi Hiện Đại Nhất Hiện Nay. Với Các Công Nghệ Hiện Đại, Đảm Bảo Bạn Sẽ Thấy Thú Vị Khi Sử Dụng Auto - Bot Tại Đây." />
	<meta name="keywords" content="tang like, hack like facebook, buff like, auto cam xuc , bot cam xuc , bot like , bot ex like , hack like viet nam, https://hotlike.net, trang web hack like facebook, auto like viet nam, buff like viet nam,cách tăng like stt facebook, hack like ảnh facebook, auto cam xuc , bot cam xuc , bot like , bot ex like  hack like comment facebook, tăng like ảnh facebook, cách hack tăng like,share code auto like, xin code auto like, web auto like, auto sub , auto share , hack share , hack comments , hack bình luận, auto like sub , đọc trộm tin nhắn facebook , xem tin nhắn facebook không cần mật khẩu " />
	<meta name="author" content="Trung Hậu" />
	<meta name="copyright" content="Copyright © 2016 Trung Hậu" />
	<title>Không Tìm Thấy Trang Này!</title>
	<link href="<?php echo $domain; ?>/images/favicon.png" rel="shortcut icon" />
	<link href="<?php echo $domain; ?>/styles/css/ken.css" rel="stylesheet" />
	<!--[if lt IE 9]>
	<script src="<?php echo $domain; ?>/styles/js/html5shiv.js"></script>
	<script src="<?php echo $domain; ?>/styles/js/respond.min.js"></script>
	<![endif]-->
</head>
<body class="body-404">
	<div class="container">
		<section class="error-wrapper">
			<i class="icon-404"></i>
			<h1>404</h1>
			<h2>Trang Không Tìm Thấy</h2>
			<p class="page-404">Xin Lỗi, Trang Không Thể Tìn Thấy Hoặc Đã Bị Xoá, Vui Lòng Quay Trở Lại Trang Chủ <a href="index.html">Tại Đây</a></p>
		</section>
	</div>
</body>
</html>
<?php $work->closedb(); ?>